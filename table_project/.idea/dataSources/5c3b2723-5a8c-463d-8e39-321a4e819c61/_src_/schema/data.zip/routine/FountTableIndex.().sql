CREATE PROCEDURE `FountTableIndex`()
  begin
    declare TableName varchar(64);   
     
    DECLARE cur_FountTableIndex CURSOR FOR SELECT DISTINCT TABLE_NAME FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_SCHEMA = "data" and TABLE_NAME not like '%delete%' ;
    DECLARE EXIT HANDLER FOR not found CLOSE cur_FountTableIndex;
    #打开游标
    OPEN cur_FountTableIndex;
    REPEAT
     FETCH cur_FountTableIndex INTO TableName;
     SET @SQLSTR1 = CONCAT('show index from ',TableName);
     PREPARE STMT1 FROM @SQLSTR1;
     EXECUTE STMT1;
      
     DEALLOCATE PREPARE STMT1;    
       
     UNTIL 0 END REPEAT;
  #关闭游标
  CLOSE cur_FountTableIndex;
  
END