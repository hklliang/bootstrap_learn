CREATE PROCEDURE `FountTable`()
  begin
    declare TableName varchar(64);   
     
    DECLARE cur_FountTable CURSOR FOR SELECT DISTINCT TABLE_NAME FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_SCHEMA = "data" ;
    DECLARE EXIT HANDLER FOR not found CLOSE cur_FountTable;
    #打开游标
    OPEN cur_FountTable;
    REPEAT
     FETCH cur_FountTable INTO TableName;
     SET @SQLSTR1 = CONCAT('show index from ',TableName);
     PREPARE STMT1 FROM @SQLSTR1;
     EXECUTE STMT1;
      
     DEALLOCATE PREPARE STMT1;    
       
     UNTIL 0 END REPEAT;
  #关闭游标
  CLOSE cur_FountTable;
  
END