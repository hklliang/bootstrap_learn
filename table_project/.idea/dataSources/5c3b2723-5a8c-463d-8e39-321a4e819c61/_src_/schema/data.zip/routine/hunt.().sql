CREATE PROCEDURE `hunt`()
  begin
    DECLARE done int default false;
    DECLARE tablename CHAR(255);

    DECLARE cur1 cursor for SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES
                  WHERE table_schema ='data';
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    open cur1;
       myloop: loop
        fetch cur1 into tablename;
        if done then
            leave myloop;
        end if;
        set @sql = CONCAT('select count(*) from `data`.',tablename);
        prepare stmt from @sql;
        execute stmt;
        drop prepare stmt;
    end loop;

    close cur1;
end